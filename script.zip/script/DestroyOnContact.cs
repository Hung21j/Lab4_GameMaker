using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class DestroyOnContact : MonoBehaviour
{
    public GameObject exRock, exPlayer;

    public AudioSource exMusic;

    private GameController gameController;

    private void Start()
    {
        GameObject controller = GameObject.FindWithTag("GameController");
        if (controller != null)
        {
            gameController = controller.GetComponent<GameController>();
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Boundary")
        {
            return;
        }
        
        Instantiate(exRock, transform.position, transform.rotation);
        Destroy(other.gameObject);
        Destroy(gameObject);
        gameController.Show();
        if (other.tag == "Player")
        {
            Instantiate(exPlayer, transform.position, transform.rotation);
            Destroy(other.gameObject);
            Destroy(gameObject);
            exMusic.Play();
            gameController.GameOver();
            gameController.Restart();
        }
        
        
    }
}
