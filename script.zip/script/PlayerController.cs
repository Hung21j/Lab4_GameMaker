using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}
public class PlayerController : MonoBehaviour
{
    public AudioSource shoot;
    public Boundary bound;

    public Rigidbody rbody;

    public GameObject Bullet;

    public Transform Bulletsp;

    public float speed = 20;
    public float tilt;
    public float fireRate;
    private float timeRate;


    void Start()
    {
        rbody = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (Input.GetButton("Fire1") && Time.time > timeRate)
        {
            timeRate = Time.time + fireRate;
            Instantiate(Bullet, Bulletsp.position, Bulletsp.rotation);
            shoot.Play();
        }
    }

    void FixedUpdate()
    {
        var hor = Input.GetAxis("Horizontal");
        var ver = Input.GetAxis("Vertical");

        Vector3 vector3 = new Vector3(hor, 0, ver);
        rbody.velocity = vector3 * speed;

        transform.position = new Vector3(
            Mathf.Clamp(transform.position.x, bound.xMin, bound.xMax),
            0,
            Mathf.Clamp(transform.position.z, bound.zMin, bound.zMax)
            );
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, rbody.velocity.x * -tilt));
    }
}
