using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


[System.Serializable]
public class Boundary_a
{
    public float xMinMax;
    public float zMin;
    public float count;
    public float startWait;
    public float cloneWait;
}
public class GameController : MonoBehaviour
{
    public TextMeshProUGUI score, over, restart;

    public Boundary_a bound;

    public GameObject rock;

    private float count = 0;

    private bool gameOver, gameRestart;

    public AudioSource background;

    private void Start()
    {
        gameRestart = gameOver = false;
;       StartCoroutine(Waves());
        score.text = "Score: " + count;
        over.text = "";
        restart.text = "";
    }

    private void Update()
    {
        if (gameRestart && Input.GetKeyDown(KeyCode.S))
        {
            Application.LoadLevel(Application.loadedLevel);
            
        }
    }
    IEnumerator Waves()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);
            for (int i = 0; i < bound.count; i++)
            {
                Instantiate(rock, new Vector3(Random.Range(-bound.xMinMax, bound.xMinMax), 0, bound.zMin), Quaternion.identity);
                yield return new WaitForSeconds(bound.cloneWait);
            }
            yield return new WaitForSeconds(bound.startWait);
            if (gameOver == true)
            {
                break;
            }
        }
        
    }

    public void GameOver()
    {
        over.text = "GAME OVER !!";
        gameOver = true;
        background.Stop();
    }

    public void Restart()
    {
        restart.text = "Press S to restart!";
        gameRestart = true;
    }
    public void Show()
    {
        count++;
        score.text = "Score: " + count;
    }

        
}
